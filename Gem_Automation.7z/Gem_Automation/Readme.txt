# Gem_Automation Setup

## Prerequisites
- Python 3.x
- pip

## Install dependencies
pip install -r requirements.txt


## Running Tests
robot -d Results -v TARGET_IP:<ip-address> -v backendSettings_audi_backend:<Audi backend to be configured>  Tests/GemTestSuite.robot